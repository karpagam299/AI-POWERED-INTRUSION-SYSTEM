import scapy.all as scapy
import tkinter as tk
from tkinter import messagebox
import threading
import time

class IntrusionDetectionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Intrusion Detection System")
        self.root.geometry("600x400")
        self.root.configure(bg="black")

        # GUI elements
        self.alert_label = tk.Label(root, text="Start", font=("Arial", 14), fg="white", bg="black")
        self.alert_label.pack(pady=20)

        self.start_button = tk.Button(root, text="Start Sniffing", command=self.start_sniffing, bg="grey", fg="white", font=("Arial", 12, "bold"))
        self.start_button.pack(pady=20)

        # Initialize the seen ARP pairs dictionary and timestamp for last detection
        self.seen_arp_pairs = {}
        self.last_detection_time = time.time()  # Start with the current time

        # Start the periodic check for no intrusion
        self.check_no_intrusion_thread = threading.Thread(target=self.check_no_intrusion, daemon=True)
        self.check_no_intrusion_thread.start()

    def start_sniffing(self):
        self.alert_label.config(text="Sniffing started...")
        self.root.update_idletasks()

        sniff_thread = threading.Thread(target=self.sniff_packets, daemon=True)
        sniff_thread.start()

    def sniff_packets(self):
        interface = "eth0"  # Force it to use eth0
        print(f"[DEBUG] Sniffing on interface: {interface}")
        scapy.sniff(
            iface=interface,
            prn=self.process_packet,
            store=False,
            filter="arp"
        )

    def process_packet(self, packet):
        if packet.haslayer(scapy.ARP) and packet[scapy.ARP].op == 2:
            ip = packet[scapy.ARP].psrc
            mac = packet[scapy.ARP].hwsrc

            # Check if we've seen this IP-MAC pair before
            if ip not in self.seen_arp_pairs or self.seen_arp_pairs[ip] != mac:
                # Update the MAC address for this IP
                self.seen_arp_pairs[ip] = mac
                self.last_detection_time = time.time()  # Reset the detection time

                msg = f"⚠ Intrusion Detected!\nIP: {ip}, MAC: {mac}"
                print("[ALERT]", msg)
                self.alert_label.config(text=msg)
                self.root.update_idletasks()

    def check_no_intrusion(self):
        while True:
            current_time = time.time()
            # If more than 10 seconds have passed since the last detection, update to "No Intrusion Detected"
            if current_time - self.last_detection_time > 10:
                self.alert_label.config(text="No Intrusion Detected")
                self.root.update_idletasks()
            time.sleep(2)  # Check every 2 seconds

# Entry point
if __name__ == "__main__":
    root = tk.Tk()
    app = IntrusionDetectionApp(root)
    root.mainloop()
