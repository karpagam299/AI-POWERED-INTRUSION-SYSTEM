from scapy.all import sniff, ARP
import netifaces

def get_mac(ip):
    """
    Get MAC address for a given IP address using ARP.
    """
    ans, _ = ARP(pdst=ip).sr(timeout=1, verbose=False)
    for _, rcv in ans:
        return rcv.hwsrc
    return None

def detect_arp_spoof(pkt):
    if pkt.haslayer(ARP) and pkt[ARP].op == 2:  # is ARP reply
        try:
            real_mac = get_mac(pkt[ARP].psrc)
            response_mac = pkt[ARP].hwsrc
            if real_mac and real_mac != response_mac:
                print("⚠ ALERT: Possible ARP Spoofing Detected!")
                print(f"IP: {pkt[ARP].psrc}")
                print(f"Expected MAC: {real_mac}, Received MAC: {response_mac}\n")
        except Exception as e:
            print(f"Error: {e}")

def get_interface():
    """
    Auto-detect the active network interface.
    """
    gateways = netifaces.gateways()
    default_iface = gateways['default'][netifaces.AF_INET][1]
    return default_iface

def start_sniffing():
    iface = get_interface()
    print(f"[INFO] Sniffing started on interface {iface}...")
    sniff(filter="arp", store=False, prn=detect_arp_spoof, iface=iface)
