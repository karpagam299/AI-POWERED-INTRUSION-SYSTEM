import tkinter as tk
from scapy.all import sniff, Ether
import threading

# Define the suspicious MAC address (you can change this)
SUSPICIOUS_MAC = "00:11:22:33:44:55"

# Function to detect intrusion
def detect_intrusion(packet):
    if packet.haslayer(Ether):
        src_mac = packet[Ether].src
        if src_mac == SUSPICIOUS_MAC:
            return True
    return False

# GUI update function
def update_status(message):
    status_label.config(text=message)

# Function to run sniffing in the background
def start_sniffing():
    def sniff_packets():
        sniff(prn=process_packet, store=0)
    thread = threading.Thread(target=sniff_packets, daemon=True)
    thread.start()

# Function to process each packet
def process_packet(packet):
    if detect_intrusion(packet):
        update_status("🚨 Intrusion Detected!")
    else:
        update_status("✅ Monitoring...")

# GUI setup
def create_gui():
    global status_label
    window = tk.Tk()
    window.title("WiFi Intrusion Detection System")
    window.geometry("400x200")
    window.configure(bg="black")

    title = tk.Label(window, text="WiFi Intrusion Detection", fg="lime", bg="black", font=("Arial", 16, "bold"))
    title.pack(pady=10)

    status_label = tk.Label(window, text="Waiting for packets...", fg="white", bg="black", font=("Arial", 12))
    status_label.pack(pady=20)

    start_button = tk.Button(window, text="Start Monitoring", command=start_sniffing, bg="lime", fg="black", font=("Arial", 12, "bold"))
    start_button.pack(pady=10)

    window.mainloop()
